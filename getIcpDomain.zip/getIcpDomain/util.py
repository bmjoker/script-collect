#!/usr/bin/env python3
#-*- coding=utf-8-*-
import subprocess
import hashlib
import re
import random
import tldextract
import socket

#按行保存内容到文件
def saveLineToFile(line, filename):
    fobj = open(filename, "a+", encoding="utf-8")
    fobj.writelines(line+"\n")
    fobj.close()


#保存列表到文件
def saveListToFile(linelists, filename):
    fobj = open(filename, "a+", encoding="utf-8")
    for line in linelists:
        fobj.writelines(line+"\n")
    fobj.close()



#读取文件内容
def readFile(filename):
    rlist  =[]
    for item in open(filename, encoding="utf-8"):
        rlist.append(item.strip())
    return rlist


if __name__=="__main__":
    print(is_internal_ip("101.10.10.10"))