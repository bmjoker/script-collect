#!/usr/bin/env python3
#-*- coding: utf-8-*-

from req import REQ
import re
from util import *
import sys
import queue
import threading
import time

# 获取注册企业名称
# https://seo.chinaz.com/lnidcode.org.cn
def get_compname(domain):
    chinazurl ="http://seo.chinaz.com/"+domain
    r = REQ(chinazurl)
    body = r.get_content()
    try:
        compname = re.findall("//data.chinaz.com/company/([^\"]+)\"", body)[0]
        compname = compname.split('-')[-1]
    except:
        compname = ""
    return compname

# 通过 企业名称获取 id
def get_compid(company):
    keylists = []
    compurl = "http://data.chinaz.com/company/t0-p0-c0-i0-d0-s-" + company
    r = REQ(compurl)
    body = r.get_content()
    
    keyword = re.findall("col-3 nofoldtxt.*/company/(\w+)\"", body)
    print(keyword)
    counts = re.findall('<span class="c-blue">([^<]+)</span>', body)
    print(counts)
    keylists.extend(keyword)
    if len(keyword)  >= 20:
        counts = re.findall('<span class="c-blue">([^<]+)</span>', body)
        print(counts)
        if len(counts) != 0:
            count = int(counts[0].replace('+', ''))
            for i in range (2, int(count / 20)):
                url = compurl + '/' + str(i)
                print(url)
                r = REQ(url)
                body = r.get_content()
                keyword = re.findall("col-3 nofoldtxt.*/company/(\w+)\"", body)
                keylists.extend(keyword)
    print(keylists)
    
    return list(set(keylists))

# 通过 id 获取企业基本信息
#<td>所属行业</td>                    <td>零售业</td>
def get_info(company, cid):
    print(company, cid)
    infourl = "http://data.chinaz.com/company/" + cid
    r = REQ(infourl)
    body = r.get_content().replace("\r", "").replace("\n", "")
    try:
        address = re.findall("<div class=\"z-fl c-36\">([^<]+)</div>", body)[0].replace("地址：", "")
    except:
        address = "-"
    try:
        icptype= re.findall("<td>公司类型</td>\s+<td>([^<]+)</td>", body)[0]
    except:
        icptype = "-"
    try:
        indesty = re.findall("<td>所属行业</td>\s+<td>([^<]+)</td>", body)[0]
    except:
        indesty = "-"
        
    try:
        ctype = re.findall("<td>公司状态</td>\s+<td>([^<]+)</td>", body)[0]
    except:
        ctype = "-"
        
    icpinfo =  re.findall("<th>备案号</th>(.*)</tbody>", body)
    #print(icpinfo)
    if len(icpinfo) != 0:
        for item in icpinfo[0].split("</tr>"):
            dinfo = re.findall("<td>([^<]+)</td>", item)
            try:
                compname = dinfo[2]
            except:
                compname = "-"
            try:
                website = dinfo[3]
            except:
                website = "-"
            try:
                icpnum = dinfo[4]
            except:
                icpnum = "-"
            saveLineToFile(compname  + "\t" + website + "\t" + address + "\t" + icpnum + "\t" + indesty + "\t" + icptype + "\t" + ctype, "addressinfo.txt")
    else:
        saveLineToFile(company  + "\t-\t" + address + "\t-\t" + indesty + "\t" + icptype + "\t" + ctype, "addressinfo.txt")
    

if __name__=="__main__":
    l = 170000
    n = 0
    
    for domain in open(sys.argv[1], encoding='utf-8'):
        compname = get_compname(domain.strip())
        clist = get_compid(compname)
        n = n + 1
        print(n, l, compname)
        for cid in clist:
            get_info(compname, cid)
       